//Predict1: I was born in 1980
//Predict2: I was born in 1980
//Predict3: Summing Numbers!
          //num1 is: 10
          //num1 is: 20
          //30
    