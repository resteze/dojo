class Ninja{
    constructor(name,speed = 3, strength = 3){
        this.name = name;
        this.health = 100;
        this.speed = speed;
        this.strength = strength 
    }
    sayName(){
        console.log(`Hi, my name is ${this.name}!`)
    }
    showStats(){
        console.log(`Here is ${this.name}'s stats:`)
        console.log(this)
        
    }
    drinkSake(){
        this.health += 10;
        console.log(`${this.name} drank Sake and gained health!`)
    }

}

const ninja1 = new Ninja("Hyabusa")
ninja1.sayName();
ninja1.showStats();
