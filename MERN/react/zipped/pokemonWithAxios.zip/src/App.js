import './App.css';
import React from 'react';
import GrabAllPokemon from './views/grabPokemon';

function App() {
  return (
    <div>
      <GrabAllPokemon/>
    </div>
  );
}

export default App;
