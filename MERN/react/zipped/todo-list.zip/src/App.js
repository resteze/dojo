import './App.css';
import PageDisplay from "../src/views/pageDisplay";

function App() {
  return (
    <div className="App">
      <PageDisplay />
    </div>
  )
};

export default App;
