import React from "react";
import Form from "./component1";

const displayForm = (props) => {
    return(
        <div>
            <p>Your Form Data</p>
            <p> First Name: {Form.newUser.firstName} </p>
            <p> Last Name: {props.newUser.lastName} </p>
            <p> Email: {props.newUser.email} </p>
            <p> Password: {props.newUser.password} </p>
            <p> Confirm Password: {props.newUser.confirmPassword} </p>
        </div>
        
    )
}

export default displayForm;