import './App.css';
import React from 'react';
import PageDisplay from './view/pageDisplay';

function App(props) {
  return (
    <div>
      <PageDisplay/>
    </div>
  );
}

export default App;
