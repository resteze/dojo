//import express
const {faker} = require('@faker-js/faker')
const express = require('express')
app = express()

const createUser = () => {
    const newUser = {
        password: faker.internet.password(),
        email: faker.internet.email(),
        phoneNumber: faker.phone.number(),
        lastName: faker.name.lastName(),
        firstName: faker.name.firstName(),
        _id:  faker.datatype.number()
    }
    return newUser
}
const createCompany = () => {
    const newCompany = {
        _id: faker.datatype.number(),
        name: faker.company.name(),
        address: {
            street: faker.address.street(),
            city: faker.address.city(),
            state: faker.address.state(),
            zipCode: faker.address.zipCode(),
            country: faker.address.country()
        }
    }
    return newCompany
}

//routing
app.get('/api/users/:new', (req, res)=>{
    res.json(createUser())
})
app.get('/api/companies/new', (req, res)=>{
    res.json(createCompany())
})

app.get('/api/user/company', (req, res)=>{
    res.json({user:createUser(), company:createCompany()});
})

app.listen(8000, ()=> console.log('Listening on port 8000'))