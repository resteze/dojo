const ProductController = require('../controllers/products.controller')

module.exports = app => {
    app.post('/', ProductController.createProduct)
}