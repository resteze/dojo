import { Route, Routes } from 'react-router-dom';
import './App.css';
import ProductForm from './views/CreatePage'
function App() {
  return (
    <div >
      <Routes>
        <Route path='/' element={<ProductForm />} />
      </Routes>
    </div>
  );
}

export default App;
