const {Product} = require('../models/product.model')

module.exports.createProduct = (req, res) => {
    const { productName, productPrice, productDesc } = req.body
    Product.create({ productName, productPrice, productDesc })
        .then(newProduct => res.json(newProduct))
        .catch(err => res.json(err))
};
