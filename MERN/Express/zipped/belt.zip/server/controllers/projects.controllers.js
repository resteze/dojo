const {Project} = require('../models/project.model')

module.exports.createProject = (req, res) => {
    const {projectName, projectDate, projectStatus} = req.body
    Project.create({projectName, projectDate, projectStatus})
        .then(newProject => res.json(newProject))
        .catch(err => res.json(err))
}
module.exports.getAllProjects = (req, res) => {
    Project.find({})
        .then(projects => res.json(projects))
        .catch(err => res.json(err))
}
module.exports.deleteProject = (req, res) => {
    Project.deleteOne({_id: req.params.id})
        .then(deleteConfirmation => res.json(deleteConfirmation))
        .catch(err => res.json(err))
}
module.exports.updateStatus = (req, res) => {
    Project.findOneAndUpdate({_id: req.params.id}, req.body, {new: true})
    .then(updatedStatus => res.json(updatedStatus))
    .catch(err => res.json(err))
} 
module.exports.getOneProject = (req, res) => {
    Project.findOne({_id: req.params.id})
        .then(project => res.json(project))
        .catch(err => res.json(err))
}