const mongoose = require('mongoose')
const ProjectSchema = new mongoose.Schema({
    projectName: {type: String, required: [true, 'Project Name is required' ], min: [3, 'Project Name must be at least 3 characters long']}, 
    projectDate: {type: String, required: [true, 'Project Date is required']}, 
    projectStatus: {type: String}
}, {timestamps: true})
module.exports.Project = mongoose.model('Project', ProjectSchema)