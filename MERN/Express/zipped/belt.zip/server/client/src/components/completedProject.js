import React, { useEffect, useState } from "react";
import axios from "axios";

const CompletedProjects = (props) => {
    const { removeFromDom } = props
    const { completedProjects } = props
    const [projectName, setProjectName] = useState('')
    const [projectDate, setProjectDate] = useState('')
    const [projectStatus, setProjectStatus] = useState('')

    useEffect(() => {
        axios.get(`http://localhost:8000/api/${completedProjects}`)
            .then(res => { const project = res.data; setProjectName(project.projectName); setProjectDate(project.projectDate); setProjectStatus(projectStatus) })
    })

    const deletingProject = (projectId) => {
        axios.put(`http://localhost:8000/api/update/${projectId}`, projectStatus, projectDate, projectName)
            .then(res => { removeFromDom(projectId) })
            .catch(err => console.error(err))
    }
    return (
        <div>
            {completedProjects.map((project, i) =>
                <h4 key={i}>
                    {project.projectName}
                    <div>
                        <p>Due by: {project.projectDate}</p>
                    </div>
                    <div>
                        <button onClick={(e) => { deletingProject(project._id) }}> Delete Project </button>
                    </div>
                </h4>)}
        </div>
    )
}
export default CompletedProjects