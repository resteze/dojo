import React, { useEffect, useState } from "react";
import axios from "axios";

const InProgressProjects = (props) => {
    const { inProgressProjects } = props
    const { finishProject } = props
    const [projectName, setProjectName] = useState('')
    const [projectDate, setProjectDate] = useState('')
    const [projectStatus, setProjectStatus] = useState('')

    useEffect(() => {
        axios.get(`http://localhost:8000/api/${inProgressProjects}`)
            .then(res => { const project = res.data; setProjectName(project.projectName); setProjectDate(project.projectDate); setProjectStatus(projectStatus) })
    })

    const finishingProject = (projectId) => {
        axios.put(`http://localhost:8000/api/update/${projectId}`, projectStatus, projectDate, projectName)
            .then(res => { finishProject(projectId) })
            .catch(err => console.error(err))
    }
    return (
        <div>
            {inProgressProjects.map((project, i) =>
                <h4 key={i}>
                    {project.projectName}
                    <div>
                        <p>Due by: {project.projectDate}</p>
                    </div>
                    <div>
                        <button onClick={(e) => { finishingProject(project._id) }}> Move to Completed </button>
                    </div>
                </h4>)}
        </div>
    )
}
export default InProgressProjects