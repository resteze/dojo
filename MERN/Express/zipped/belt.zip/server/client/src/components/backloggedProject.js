import React, { useEffect, useState } from "react";
import axios from "axios";

const BackloggedProjects = (props) => {
    const { backloggedProjects } = props
    const { startProject } = props
    const [projectName, setProjectName] = useState('')
    const [projectDate, setProjectDate] = useState('')
    const [projectStatus, setProjectStatus] = useState('')

    useEffect(() => {
        axios.get(`http://localhost:8000/api/${backloggedProjects}`)
            .then(res => { const project = res.data; setProjectName(project.projectName); setProjectDate(project.projectDate); setProjectStatus(projectStatus) })
    })

    const startingProject = (projectId) => {
        axios.put(`http://localhost:8000/api/update/${projectId}`, projectStatus, projectDate, projectName)
            .then(res => { 
                startProject(projectId) 
            })
            .catch(err => console.error(err))
    }
    return (
        <div>
            {backloggedProjects.map((project, i) =>
                <h4 key={i}>
                    {project.projectName}
                    <div>
                        <p>Due by: {project.projectDate}</p>
                    </div>
                    <div>
                        <button onClick={(e) => { startingProject(project._id) }}> Start Project </button>
                    </div>
                </h4>)}
        </div>
    )
}
export default BackloggedProjects