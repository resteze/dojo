import React, {useEffect, useState} from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
const ProjectForm = (props) => {
    const navigate = useNavigate()
    const [projects, setProjects] = useState([])
    const [projectName, setProjectName] = useState('')
    const [projectDate, setProjectDate] = useState('')
    const [projectStatus] = useState('Backlogged')

    useEffect(() => {
        axios.get('http://localhost:8000/api/')
        .then(res => {
            setProjects(res.data)
        })
    })

    const addToDom = project => {setProjects([...projects, project])}

    const handleSubmit = e => {
        e.preventDefault()
        axios.post('http://localhost:8000/api/new/', {projectName, projectDate, projectStatus})
        .then(res => {
            addToDom(res.data) 
            navigate('/') 
        })
            .catch(err => console.log(err))
    }
    return(
        <div>
            <h1>Project Manager</h1>
            <form onSubmit={handleSubmit}>
                <label>Project Name</label>
                <input type='text' value={props.projectName} onChange={(e)=>{setProjectName(e.target.value)}}/>
                <label>Due Date</label>
                <input type='date' value={props.projectDate} onChange={(e)=>{setProjectDate(e.target.value)}}/>
                <input type= 'submit' value='Plan Project'/>
            </form>
        </div>
    )
}
export default ProjectForm