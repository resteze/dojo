import React, { useEffect, useState } from "react";
import axios from "axios";
import BackloggedProjects from '../components/backloggedProject'
import InProgressProjects from '../components/inProgressProjects'
import CompletedProjects from '../components/completedProject'
const Main = (props) => {
    const [backloggedProjects, setBackloggedProjects] = useState([])
    const [inProgressProjects, setInProgressProjects] = useState([])
    const [completedProjects, setCompletedProjects] = useState([])
    const [loaded, setLoaded] = useState(false)
    console.log('Backlog:', backloggedProjects)
    console.log('In Progress:', inProgressProjects)
    console.log('Completed:', completedProjects)
    useEffect(() => {
        axios.get('http://localhost:8000/api/')
            .then(res => {
                setBackloggedProjects(res.data.filter(project => project.projectStatus === 'Backlogged'));
                setInProgressProjects(res.data.filter(project => project.projectStatus === 'InProgress'));
                setCompletedProjects(res.data.filter(project => project.projectStatus === 'Completed'));
                setLoaded(true);
            })
            .catch(err => console.log(err))
    }, [])

    const removeFromDom = project => { setCompletedProjects(completedProjects.filter(completedProjects => completedProjects._id !== project)) }

    const startProject = project => {
        setInProgressProjects([...inProgressProjects, project]);
        setBackloggedProjects(backloggedProjects.filter(backloggedProjects => backloggedProjects._id !== project));
        project.projectStatus = 'InProgress';
    }

    const finishProject = project => { setCompletedProjects([...completedProjects, project]); setInProgressProjects(inProgressProjects.filter(inProgressProjects => inProgressProjects._id !== project)); project.projectStatus = 'Completed'; }

    return (
        <div>
            <h1> Project Manager</h1>
            <div>
                <h2> Backlog </h2>
                {loaded && <BackloggedProjects backloggedProjects={backloggedProjects} startProject={startProject} />}
            </div>
            <div>
                <h2> In Progress </h2>
                {loaded && <InProgressProjects inProgressProjects={inProgressProjects} finishProject={finishProject} />}
            </div>
            <div>
                <h2> Completed </h2>
                {loaded && <CompletedProjects completedProjects={completedProjects} removeFromDom={removeFromDom} />}
            </div>
            <a href='/new'><button> Add New Project </button></a>
        </div>
    )
}
export default Main