import {Route, Routes} from 'react-router-dom';
import Main from './views/Main'
import ProjectForm  from './views/createProject';
import './App.css';

function App() {
  return (
    <div>
      <Routes>
        <Route path='/' element={<Main/>}/>
        <Route path='/new' element={<ProjectForm/>}/>
      </Routes>
    </div>
  );
}

export default App;
