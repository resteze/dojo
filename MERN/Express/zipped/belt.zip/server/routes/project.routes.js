const ProjectController = require('../controllers/projects.controllers')

module.exports = app => {
    app.get('/api/', ProjectController.getAllProjects)
    app.get('/api/:id', ProjectController.getOneProject)
    app.post('/api/new/', ProjectController.createProject)
    app.put('/api/update/:id', ProjectController.updateStatus)
    app.delete('/api/:id', ProjectController.deleteProject)
}