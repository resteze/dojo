import React, { useEffect, useState } from 'react'
import ProductForm from '../component/CreatePage';
import AllProducts from '../component/AllProduct';
import axios from 'axios';

const Main = (props) => {
    const [products, setProducts] = useState([]);
    const [loaded, setLoaded] = useState(false);

    useEffect(() => {
        axios.get('http://localhost:8000/all')
            .then(res => {
                setProducts(res.data);
                setLoaded(true);
            })
            .catch(err => console.error(err));
    }, []);

    return (
        <div>
            <ProductForm />
            <hr />
            {loaded && <AllProducts products={products} />}
        </div>
    )
}

export default Main;

