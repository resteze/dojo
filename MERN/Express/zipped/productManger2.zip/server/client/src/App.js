import { Route, Routes } from 'react-router-dom';
import Product from './component/Product';
import './App.css';
import Main from './views/Main';
function App() {
  return (
    <div >
      <Routes>
        <Route path='/' element={<Main />} />
        <Route path='/:id' element={<Product />} />
      </Routes>
    </div>
  );
}

export default App;
