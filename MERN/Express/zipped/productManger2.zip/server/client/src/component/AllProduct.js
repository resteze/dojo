import React from "react"
import axios from "axios";
import { Link } from "react-router-dom";

const AllProducts = (props) => {
    return(
        <div>
            {props.products.map((product, i) => <Link to={`/${product._id}`} key ={i}>{product.productName}</Link> )}
        </div>
    )
}
export default AllProducts