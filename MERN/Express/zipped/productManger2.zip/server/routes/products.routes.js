const ProductController = require('../controllers/products.controller')

module.exports = app => {
    app.get('/all', ProductController.getAllProducts)
    app.get('/:id', ProductController.getProduct)
    app.post('/', ProductController.createProduct)
}