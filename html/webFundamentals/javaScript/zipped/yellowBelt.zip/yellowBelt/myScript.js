function emptyAlert() {
    window.alert("Your Cart is Empty!");
}
function changeImg() {
    document.querySelector("#suc1").src ="./images/assets/succulents-2.jpg";
}
function changeImgBack() {
    document.querySelector("#suc1").src = "./images/assets/succulents-1.jpg";
}
function cookies(){
    window.alert('This site makes use of third-party cookies by clicking "I accept" you agree to the terms outlined in our <a href="#"> cookie policy.</a>')
}