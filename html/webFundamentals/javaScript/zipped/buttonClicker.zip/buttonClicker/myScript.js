function changeLogin(element) {
    element.innerText = "Logout";
}
function removeElement(element) {
    element.remove()
}