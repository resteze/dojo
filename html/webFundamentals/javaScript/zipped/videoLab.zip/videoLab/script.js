var vid = document.getElementById("video");
function play(){
    vid.play();
}
function pauseVid() {
    vid.pause();
}