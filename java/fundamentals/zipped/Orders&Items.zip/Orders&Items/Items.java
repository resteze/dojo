class Items {
    public String name;
    public double price;
    
}
