import java.util.ArrayList;

class Orders{
    public String name;
    public double total;
    public boolean ready;
    public ArrayList<Items>items;
}