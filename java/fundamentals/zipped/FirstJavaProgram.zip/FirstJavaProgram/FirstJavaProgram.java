public class FirstJavaProgram {
    public static void main(String[] args) {
        String name = "David";
        Integer age = 21;
        String hometown = "Minneapolis, MN";
        System.out.format("My name is %s %n" , name);
        System.out.format("I am %d years old %n", age);
        System.out.format("My hometown is %s %n", hometown);
    }
}