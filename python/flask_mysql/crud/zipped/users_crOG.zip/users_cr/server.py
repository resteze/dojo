from flask import Flask, render_template, redirect, session, request
from flask_app.users import User
app = Flask(__name__)
app.secret_key = 'whatstheword'


#view route
@app.route('/users')
def showUsers():
    all_users = User.get_all()
    print(all_users)
    return render_template('read.html', all_users = all_users)

#view route for form
@app.route('/users/new')
def addUser():
    return render_template('create.html')

#action route
@app.route('/users/create', methods = ['post']) 
def createUser():
    User.save(request.form)
    return redirect('/users')

if __name__ == '__main__':
    app.run(debug=True)